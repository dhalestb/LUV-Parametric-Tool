# height-only-60-40-20

Validation result: geometry checked

See ../README.md and this folder manifest.json, validation.json, validation.log and intersection-diagnostics.json. Failed previews are not approved geometry.